"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./components/CartContext.js":
/*!***********************************!*\
  !*** ./components/CartContext.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"CartContext\": () => (/* binding */ CartContext),\n/* harmony export */   \"CartContextProvider\": () => (/* binding */ CartContextProvider)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst CartContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});\nfunction CartContextProvider({ children  }) {\n    const ls =  false ? 0 : null;\n    const [cartProducts, setCartProducts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        if (cartProducts?.length > 0) {\n            ls?.setItem(\"cart\", JSON.stringify(cartProducts));\n        }\n    }, [\n        cartProducts\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        if (ls && ls.getItem(\"cart\")) {\n            setCartProducts(JSON.parse(ls.getItem(\"cart\")));\n        }\n    }, []);\n    function addProduct(productId) {\n        setCartProducts((prev)=>[\n                ...prev,\n                productId\n            ]);\n    }\n    function removeProduct(productId) {\n        setCartProducts((prev)=>{\n            const pos = prev.indexOf(productId);\n            if (pos !== -1) {\n                return prev.filter((value, index)=>index !== pos);\n            }\n            return prev;\n        });\n    }\n    function clearCart() {\n        setCartProducts([]);\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(CartContext.Provider, {\n        value: {\n            cartProducts,\n            setCartProducts,\n            addProduct,\n            removeProduct,\n            clearCart\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"D:\\\\FOIT\\\\FOIT_2123_Webshop\\\\webshop-front\\\\components\\\\CartContext.js\",\n        lineNumber: 34,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0NhcnRDb250ZXh0LmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBeUQ7QUFFbEQsTUFBTUcsNEJBQWNILG9EQUFhQSxDQUFDLENBQUMsR0FBRztBQUV0QyxTQUFTSSxvQkFBb0IsRUFBQ0MsU0FBUSxFQUFDLEVBQUU7SUFDOUMsTUFBTUMsS0FBSyxNQUE2QixHQUFHQyxDQUFtQixHQUFHLElBQUk7SUFDckUsTUFBTSxDQUFDRSxjQUFhQyxnQkFBZ0IsR0FBR1IsK0NBQVFBLENBQUMsRUFBRTtJQUNsREQsZ0RBQVNBLENBQUMsSUFBTTtRQUNkLElBQUlRLGNBQWNFLFNBQVMsR0FBRztZQUM1QkwsSUFBSU0sUUFBUSxRQUFRQyxLQUFLQyxTQUFTLENBQUNMO1FBQ3JDLENBQUM7SUFDSCxHQUFHO1FBQUNBO0tBQWE7SUFDakJSLGdEQUFTQSxDQUFDLElBQU07UUFDZCxJQUFJSyxNQUFNQSxHQUFHUyxPQUFPLENBQUMsU0FBUztZQUM1QkwsZ0JBQWdCRyxLQUFLRyxLQUFLLENBQUNWLEdBQUdTLE9BQU8sQ0FBQztRQUN4QyxDQUFDO0lBQ0gsR0FBRyxFQUFFO0lBQ0wsU0FBU0UsV0FBV0MsU0FBUyxFQUFFO1FBQzdCUixnQkFBZ0JTLENBQUFBLE9BQVE7bUJBQUlBO2dCQUFLRDthQUFVO0lBQzdDO0lBQ0EsU0FBU0UsY0FBY0YsU0FBUyxFQUFFO1FBQ2hDUixnQkFBZ0JTLENBQUFBLE9BQVE7WUFDdEIsTUFBTUUsTUFBTUYsS0FBS0csT0FBTyxDQUFDSjtZQUN6QixJQUFJRyxRQUFRLENBQUMsR0FBRztnQkFDZCxPQUFPRixLQUFLSSxNQUFNLENBQUMsQ0FBQ0MsT0FBTUMsUUFBVUEsVUFBVUo7WUFDaEQsQ0FBQztZQUNELE9BQU9GO1FBQ1Q7SUFDRjtJQUNBLFNBQVNPLFlBQVk7UUFDbkJoQixnQkFBZ0IsRUFBRTtJQUNwQjtJQUNBLHFCQUNFLDhEQUFDUCxZQUFZd0IsUUFBUTtRQUFDSCxPQUFPO1lBQUNmO1lBQWFDO1lBQWdCTztZQUFXRztZQUFjTTtRQUFTO2tCQUMxRnJCOzs7Ozs7QUFHUCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2Vic2hvcC1mcm9udC8uL2NvbXBvbmVudHMvQ2FydENvbnRleHQuanM/ODIzZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge2NyZWF0ZUNvbnRleHQsIHVzZUVmZmVjdCwgdXNlU3RhdGV9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgY29uc3QgQ2FydENvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9KTtcblxuZXhwb3J0IGZ1bmN0aW9uIENhcnRDb250ZXh0UHJvdmlkZXIoe2NoaWxkcmVufSkge1xuICBjb25zdCBscyA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cubG9jYWxTdG9yYWdlIDogbnVsbDtcbiAgY29uc3QgW2NhcnRQcm9kdWN0cyxzZXRDYXJ0UHJvZHVjdHNdID0gdXNlU3RhdGUoW10pO1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjYXJ0UHJvZHVjdHM/Lmxlbmd0aCA+IDApIHtcbiAgICAgIGxzPy5zZXRJdGVtKCdjYXJ0JywgSlNPTi5zdHJpbmdpZnkoY2FydFByb2R1Y3RzKSk7XG4gICAgfVxuICB9LCBbY2FydFByb2R1Y3RzXSk7XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGxzICYmIGxzLmdldEl0ZW0oJ2NhcnQnKSkge1xuICAgICAgc2V0Q2FydFByb2R1Y3RzKEpTT04ucGFyc2UobHMuZ2V0SXRlbSgnY2FydCcpKSk7XG4gICAgfVxuICB9LCBbXSk7XG4gIGZ1bmN0aW9uIGFkZFByb2R1Y3QocHJvZHVjdElkKSB7XG4gICAgc2V0Q2FydFByb2R1Y3RzKHByZXYgPT4gWy4uLnByZXYscHJvZHVjdElkXSk7XG4gIH1cbiAgZnVuY3Rpb24gcmVtb3ZlUHJvZHVjdChwcm9kdWN0SWQpIHtcbiAgICBzZXRDYXJ0UHJvZHVjdHMocHJldiA9PiB7XG4gICAgICBjb25zdCBwb3MgPSBwcmV2LmluZGV4T2YocHJvZHVjdElkKTtcbiAgICAgIGlmIChwb3MgIT09IC0xKSB7XG4gICAgICAgIHJldHVybiBwcmV2LmZpbHRlcigodmFsdWUsaW5kZXgpID0+IGluZGV4ICE9PSBwb3MpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHByZXY7XG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gY2xlYXJDYXJ0KCkge1xuICAgIHNldENhcnRQcm9kdWN0cyhbXSk7XG4gIH1cbiAgcmV0dXJuIChcbiAgICA8Q2FydENvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3tjYXJ0UHJvZHVjdHMsc2V0Q2FydFByb2R1Y3RzLGFkZFByb2R1Y3QscmVtb3ZlUHJvZHVjdCxjbGVhckNhcnR9fT5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L0NhcnRDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufSJdLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJDYXJ0Q29udGV4dCIsIkNhcnRDb250ZXh0UHJvdmlkZXIiLCJjaGlsZHJlbiIsImxzIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiY2FydFByb2R1Y3RzIiwic2V0Q2FydFByb2R1Y3RzIiwibGVuZ3RoIiwic2V0SXRlbSIsIkpTT04iLCJzdHJpbmdpZnkiLCJnZXRJdGVtIiwicGFyc2UiLCJhZGRQcm9kdWN0IiwicHJvZHVjdElkIiwicHJldiIsInJlbW92ZVByb2R1Y3QiLCJwb3MiLCJpbmRleE9mIiwiZmlsdGVyIiwidmFsdWUiLCJpbmRleCIsImNsZWFyQ2FydCIsIlByb3ZpZGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/CartContext.js\n");

/***/ }),

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ \"styled-components\");\n/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_CartContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/components/CartContext */ \"./components/CartContext.js\");\n\n\n\nconst GlobalStyles = styled_components__WEBPACK_IMPORTED_MODULE_1__.createGlobalStyle`\n  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');\n  body{\n    background-color: #eee;\n    padding:0;\n    margin:0;\n    font-family: 'Poppins', sans-serif;\n  }\n`;\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(GlobalStyles, {}, void 0, false, {\n                fileName: \"D:\\\\FOIT\\\\FOIT_2123_Webshop\\\\webshop-front\\\\pages\\\\_app.js\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_CartContext__WEBPACK_IMPORTED_MODULE_2__.CartContextProvider, {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"D:\\\\FOIT\\\\FOIT_2123_Webshop\\\\webshop-front\\\\pages\\\\_app.js\",\n                    lineNumber: 19,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"D:\\\\FOIT\\\\FOIT_2123_Webshop\\\\webshop-front\\\\pages\\\\_app.js\",\n                lineNumber: 18,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBb0Q7QUFDUztBQUU3RCxNQUFNRSxlQUFlRixnRUFBaUIsQ0FBQzs7Ozs7Ozs7QUFRdkMsQ0FBQztBQUVjLFNBQVNHLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQUUsRUFBRTtJQUNwRCxxQkFDRTs7MEJBQ0UsOERBQUNIOzs7OzswQkFDRCw4REFBQ0Qsd0VBQW1CQTswQkFDbEIsNEVBQUNHO29CQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7Ozs7QUFJaEMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL3dlYnNob3AtZnJvbnQvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtjcmVhdGVHbG9iYWxTdHlsZX0gZnJvbSBcInN0eWxlZC1jb21wb25lbnRzXCI7XG5pbXBvcnQge0NhcnRDb250ZXh0UHJvdmlkZXJ9IGZyb20gXCJAL2NvbXBvbmVudHMvQ2FydENvbnRleHRcIjtcblxuY29uc3QgR2xvYmFsU3R5bGVzID0gY3JlYXRlR2xvYmFsU3R5bGVgXG4gIEBpbXBvcnQgdXJsKCdodHRwczovL2ZvbnRzLmdvb2dsZWFwaXMuY29tL2NzczI/ZmFtaWx5PVBvcHBpbnM6d2dodEA0MDA7NTAwOzYwMDs3MDAmZGlzcGxheT1zd2FwJyk7XG4gIGJvZHl7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2VlZTtcbiAgICBwYWRkaW5nOjA7XG4gICAgbWFyZ2luOjA7XG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcbiAgfVxuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8R2xvYmFsU3R5bGVzIC8+XG4gICAgICA8Q2FydENvbnRleHRQcm92aWRlcj5cbiAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgICAgPC9DYXJ0Q29udGV4dFByb3ZpZGVyPlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbImNyZWF0ZUdsb2JhbFN0eWxlIiwiQ2FydENvbnRleHRQcm92aWRlciIsIkdsb2JhbFN0eWxlcyIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-components":
/*!************************************!*\
  !*** external "styled-components" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();